from numpy import nan
from sagemaker_sklearn_extension.externals import Header
from sagemaker_sklearn_extension.feature_extraction.date_time import DateTimeVectorizer
from sagemaker_sklearn_extension.feature_extraction.text import MultiColumnTfidfVectorizer
from sagemaker_sklearn_extension.impute import RobustImputer
from sagemaker_sklearn_extension.preprocessing import RobustLabelEncoder
from sagemaker_sklearn_extension.preprocessing import RobustStandardScaler
from sagemaker_sklearn_extension.preprocessing import ThresholdOneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Given a list of column names and target column name, Header can return the index
# for given column name
HEADER = Header(
    column_names=[
        'ANY_FUEL_TYPE', 'ASSET_TYPE', 'FUNDING', 'CLASS_CLASS_BENCH',
        'CLASS_CLASS_MAINT', 'CLASS_MAINT_DESC', 'CLASS_CLASS_METER',
        'CLASS_METER_DESC', 'CLASS_CLASS_PM', 'CLASS_PM_DESC',
        'CLASS_CLASS_RENTAL', 'CLASS_RENTAL_DESC', 'CLASS_CLASS_SHOP_SCH',
        'CLASS_SHOP_DESC', 'CLASS_CLASS_STDS', 'CLASS_STDS_DESC', 'COLOR',
        'DELIVERY_DATE', 'DEPRECIATION_METHOD', 'DEPREC_MONTHS_LIFE',
        'DEPR_CUR_DECLINE_BAL', 'DEPR_MTHS_REMAINING', 'DEPT_DEPT_CODE',
        'DEPARTMENT_NAME', 'DESCRIPTION', 'EQ_EQUIP_NO', 'EST_METER_AT_REPLACE',
        'EST_REPLACE_COST', 'EST_REPLACE_MO', 'EST_REPLACE_YR',
        'HAS_TACHOGRAPH', 'IN_SERVICE_DATE', 'LAST_FUEL_DATE',
        'LAST_METER_1_DATE', 'LAST_METER_1_READING', 'LAST_METER_SOURCE',
        'LAST_PM_METER_1', 'LAST_PM_SCHED_DATE', 'LAST_PM_START_DATE',
        'LAST_PM_START_METER_1', 'LOC_ASSIGN_PM_LOC', 'LOC_ASSIGN_PM_LOC_NAME',
        'LOC_ASSIGN_REPR_LOC', 'LOC_ASSIGN_REPR_LOC_NAME', 'LOC_LAST_FUEL_LOC',
        'LOC_LAST_FUEL_LOC_NAME', 'MANUFACTURER', 'METER_1_AT_DELIVERY',
        'METER_1_TYPE', 'MODEL', 'NEXT_PM_SCHED_DATE', 'OFF_ROAD_USE',
        'ORIGINAL_COST', 'OWN_LEASE_CUSTOMER', 'PRI_SHOP_PRIORITY',
        'QTY_OPEN_WORK_ORDERS', 'RETIRE_DATE', 'SALE_DATE', 'SALE_PRICE',
        'SALVAGE_VALUE', 'STATUS_CODES', 'TAKE_HOME_ASSET', 'YEAR',
        'CAB_AXLE_LEN', 'CAPY_COOLING_SYSTEM', 'CAPY_COOLING_UNIT',
        'CAPY_DIFFERENTIAL', 'CAPY_DIFF_UNIT', 'CAPY_FUEL', 'CAPY_FUEL_UNIT',
        'CAPY_OIL', 'CAPY_OIL_UNIT', 'CAPY_TRANSFER_CASE', 'CAPY_TRANSMISSION',
        'CAPY_TRANS_UNIT', 'CAPY_TRF_CASE_UNIT', 'QTY_AXLES', 'WEIGHT_GROSS',
        'WHEELBASE', 'BC_SPEC_DATETIME', 'EMG_CLASS_ID'
    ],
    target_column_name='ASSET_TYPE'
)


def build_feature_transform():
    """ Returns the model definition representing feature processing."""

    # These features can be parsed as numeric.

    numeric = HEADER.as_feature_indices(
        [
            'DEPREC_MONTHS_LIFE', 'DEPR_CUR_DECLINE_BAL', 'DEPR_MTHS_REMAINING',
            'EST_METER_AT_REPLACE', 'EST_REPLACE_COST', 'LAST_METER_1_READING',
            'LAST_PM_METER_1', 'LAST_PM_START_METER_1', 'METER_1_AT_DELIVERY',
            'ORIGINAL_COST', 'PRI_SHOP_PRIORITY', 'QTY_OPEN_WORK_ORDERS',
            'SALE_PRICE', 'SALVAGE_VALUE', 'YEAR'
        ]
    )

    # These features contain a relatively small number of unique items.

    categorical = HEADER.as_feature_indices(
        [
            'ANY_FUEL_TYPE', 'FUNDING', 'CLASS_CLASS_BENCH', 'COLOR',
            'DEPRECIATION_METHOD', 'DEPT_DEPT_CODE', 'DEPARTMENT_NAME',
            'EST_REPLACE_MO', 'EST_REPLACE_YR', 'HAS_TACHOGRAPH',
            'LAST_METER_SOURCE', 'LOC_ASSIGN_PM_LOC', 'LOC_ASSIGN_PM_LOC_NAME',
            'LOC_ASSIGN_REPR_LOC', 'LOC_ASSIGN_REPR_LOC_NAME',
            'LOC_LAST_FUEL_LOC', 'LOC_LAST_FUEL_LOC_NAME', 'METER_1_TYPE',
            'OFF_ROAD_USE', 'OWN_LEASE_CUSTOMER', 'SALE_DATE', 'STATUS_CODES',
            'CAB_AXLE_LEN', 'CAPY_COOLING_SYSTEM', 'CAPY_COOLING_UNIT',
            'CAPY_DIFFERENTIAL', 'CAPY_DIFF_UNIT', 'CAPY_FUEL',
            'CAPY_FUEL_UNIT', 'CAPY_OIL', 'CAPY_OIL_UNIT', 'CAPY_TRANSFER_CASE',
            'CAPY_TRANSMISSION', 'CAPY_TRANS_UNIT', 'CAPY_TRF_CASE_UNIT',
            'QTY_AXLES', 'WEIGHT_GROSS', 'WHEELBASE'
        ]
    )

    # These features can be parsed as natural language.

    text = HEADER.as_feature_indices(
        [
            'CLASS_CLASS_MAINT', 'CLASS_MAINT_DESC', 'CLASS_CLASS_METER',
            'CLASS_METER_DESC', 'CLASS_CLASS_PM', 'CLASS_PM_DESC',
            'CLASS_CLASS_RENTAL', 'CLASS_RENTAL_DESC', 'CLASS_CLASS_SHOP_SCH',
            'CLASS_SHOP_DESC', 'CLASS_CLASS_STDS', 'CLASS_STDS_DESC',
            'DESCRIPTION', 'EQ_EQUIP_NO', 'LAST_FUEL_DATE', 'MANUFACTURER',
            'MODEL', 'RETIRE_DATE'
        ]
    )

    # These features can be parsed as date or time.

    datetime = HEADER.as_feature_indices(
        [
            'DELIVERY_DATE', 'IN_SERVICE_DATE', 'LAST_METER_1_DATE',
            'LAST_PM_SCHED_DATE', 'LAST_PM_START_DATE', 'NEXT_PM_SCHED_DATE',
            'BC_SPEC_DATETIME'
        ]
    )

    numeric_processors = Pipeline(
        steps=[
            (
                'robustimputer',
                RobustImputer(strategy='constant', fill_values=nan)
            )
        ]
    )

    categorical_processors = Pipeline(
        steps=[('thresholdonehotencoder', ThresholdOneHotEncoder(threshold=7))]
    )

    text_processors = Pipeline(
        steps=[
            (
                'multicolumntfidfvectorizer',
                MultiColumnTfidfVectorizer(
                    max_df=0.9974,
                    min_df=0.006,
                    analyzer='word',
                    max_features=10000
                )
            )
        ]
    )

    datetime_processors = Pipeline(
        steps=[('datetimevectorizer', DateTimeVectorizer(mode='ordinal'))]
    )

    column_transformer = ColumnTransformer(
        transformers=[
            ('numeric_processing', numeric_processors, numeric
            ), ('categorical_processing', categorical_processors,
                categorical), ('text_processing', text_processors, text),
            ('datetime_processing', datetime_processors, datetime)
        ]
    )

    return Pipeline(
        steps=[
            ('column_transformer', column_transformer
            ), ('robuststandardscaler', RobustStandardScaler())
        ]
    )


def build_label_transform():
    """Returns the model definition representing feature processing."""

    return RobustLabelEncoder(
        labels=['ASSET'],
        fill_label_value='COMPONENT',
        include_unseen_class=True
    )
